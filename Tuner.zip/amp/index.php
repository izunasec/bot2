<?php
// Config: Base URL for AMP
$baseURL = "https://jdih.kutaitimurkab.go.id/common/bacot-kontol/amp/";
$normalBaseURL = "https://jdih.kutaitimurkab.go.id/common/bacot-kontol/";

// Load files.txt from the parent directory (outside /amp)
$mapping = [];
$lines = file(__DIR__ . '/../files.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);


foreach ($lines as $line) {
    list($permalink, $title, $description, $keywords, $brand) = explode('|', $line);
    $mapping[$permalink] = [
        'title' => $title,
        'description' => $description,
        'keywords' => $keywords,
        'brand' => $brand,
    ];
}

// Detect permalink from query string (simpler for AMP handling)
$permalink = $_GET['slug'] ?? 'slot-online';

// Force fallback to "slot-online" if not found
if (!isset($mapping[$permalink])) {
    $permalink = 'slot-online';
}

// Use data from files.txt
$pageData = $mapping[$permalink];

// Build canonical (normal page URL) and AMP self link
$canonical = $normalBaseURL . $permalink;
$ampLink = $baseURL . $permalink;
?>




<!doctype html>
<html amp lang="id">
    <head>
        <meta charset="utf-8">
        <meta name="title" content="<?= htmlspecialchars($pageData['title']) ?>"/>
        <meta name="description" content="<?= htmlspecialchars($pageData['description']) ?>"/>
        <meta name="keywords" content="<?= htmlspecialchars($pageData['keywords']) ?>"/>
        <meta content="width=device-width,initial-scale=1.0,minimum-scale=1.0" name="viewport">
        <link rel="shortcut icon" href="https://i.ibb.co/yYmxmNj/favicon-1.png">
        <style amp-boilerplate>
            body {
                -webkit-animation: -amp-start 8s steps(1,end) 0s 1 normal both;
                -moz-animation: -amp-start 8s steps(1,end) 0s 1 normal both;
                -ms-animation: -amp-start 8s steps(1,end) 0s 1 normal both;
                animation: -amp-start 8s steps(1,end) 0s 1 normal both
            }

            @-webkit-keyframes -amp-start {
                from {
                    visibility: hidden
                }

                to {
                    visibility: visible
                }
            }

            @-moz-keyframes -amp-start {
                from {
                    visibility: hidden
                }

                to {
                    visibility: visible
                }
            }

            @-ms-keyframes -amp-start {
                from {
                    visibility: hidden
                }

                to {
                    visibility: visible
                }
            }

            @-o-keyframes -amp-start {
                from {
                    visibility: hidden
                }

                to {
                    visibility: visible
                }
            }

            @keyframes -amp-start {
                from {
                    visibility: hidden
                }

                to {
                    visibility: visible
                }
            }
        </style>
        <noscript>
            <style amp-boilerplate>
                body {
                    -webkit-animation: none;
                    -moz-animation: none;
                    -ms-animation: none;
                    animation: none
                }
            </style>
        </noscript>
        <script async src="https://cdn.ampproject.org/v0.js"></script>
        <script async custom-element="amp-carousel" src="https://cdn.ampproject.org/v0/amp-carousel-0.1.js"></script>
        <script async custom-element="amp-anim" src="https://cdn.ampproject.org/v0/amp-anim-0.1.js"></script>
        <script async custom-element="amp-iframe" src="https://cdn.ampproject.org/v0/amp-iframe-0.1.js"></script>
        <script async custom-element="amp-analytics" src="https://cdn.ampproject.org/v0/amp-analytics-0.1.js"></script>
        <title><?= htmlspecialchars($pageData['title']) ?></title>
        <link rel="canonical" href="<?= htmlspecialchars($canonical) ?>">
        <style amp-custom>
            .download-apk-container .modal,body {
                font-family: digital_sans_ef_medium
            }

            :root {
                --small-font: 12px;
                --normal-font: 14px;
                --large-font: 16px;
                --x-large-font: 18px
            }

            body {
                font-size: var(--small-font);
                display: flex;
                flex-direction: column;
                padding-top: 54px;
                padding-bottom: 52px;
                background: linear-gradient(0deg, #1c1c1c 0%, #000000 100%)
            }

            a {
                text-decoration: none;
                animation: 1.5s linear infinite animate;
                color: #ff0000
            }

            summary {
                outline: 0;
                list-style-type: none
            }

            summary::-webkit-details-marker {
                display: none
            }

            .container {
                align-self: center;
                margin-left: auto;
                margin-right: auto
            }

            .logo-container {
                text-align: center;
                padding: 5px;
                display: flex;
                justify-content: center;
                align-items: center;
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                z-index: 99
            }

            .logo-container .logo {
                display: block;
                position: relative;
                width: 180px;
                height: 45px
            }

            .logo-container .logo amp-img {
                flex-grow: 1
            }

            .logo-container .logo amp-img img {
                object-fit: contain
            }

            .site-menu {
                width: 60%
            }

            .site-menu amp-img {
                margin-right: 10px
            }

            .site-menu amp-img.chevron-right {
                position: absolute;
                right: 0;
                filter: invert(1);
                transition: transform .3s;
                transform-origin: center
            }

            .site-menu details[open]>summary>section>amp-img.chevron-right {
                transform: rotate(90deg)
            }

            .site-menu ul {
                list-style-type: none;
                padding: 0;
                margin: 0;
                font-size: var(--large-font)
            }

            .site-menu article>ul,.site-menu li+li,.site-menu summary {
                margin-top: 2px
            }

            .site-menu li>a,.site-menu summary {
                display: flex;
                align-items: center;
                padding: 10px 15px;
                text-decoration: none;
                cursor: pointer
            }

            .site-menu details details summary,.site-menu details li>a {
                padding-left: 45px;
                cursor: pointer;
                background-color: #0a0928
            }

            .site-menu details details li>a {
                padding-left: 75px;
                cursor: pointer;
                background-color: #040d20
            }

            .site-menu-hamburger {
                height: 18px;
                width: 18px;
                margin: 0;
                position: absolute;
                right: 25px;
                cursor: pointer
            }

            :after {
                top: 5px
            }

            .link-container {
                display: flex;
                justify-content: center;
                font-size: var(--x-large-font);
                padding: 0;
                width: 100%
            }

            .link-container a {
                width: 50%;
                text-align: center;
                padding: 15px 20px;
                text-transform: uppercase
            }

            .main-menu-container {
                list-style-type: none;
                display: flex;
                flex-wrap: wrap;
                margin: 0;
                padding: 10px 0
            }

            .main-menu-container li {
                flex-basis: calc(25% - 10px);
                padding: 5px
            }

            .main-menu-container li a {
                display: flex;
                padding: 5px 0;
                justify-content: center;
                align-items: center;
                flex-direction: column;
                font-size: var(--normal-font);
                text-transform: uppercase
            }

            .main-menu-container li amp-img {
                margin: 8px 0
            }

            .jackpot-container {
                display: flex;
                justify-content: center;
                position: relative;
                height: 175px
            }

            .footer-container .bank-list,.footer-container .contact-list,.footer-container .footer-links,.footer-container .social-media-list {
                display: flex;
                flex-wrap: wrap;
                margin: 0 auto;
                padding: 10px 0;
                list-style-type: none
            }

            .footer-container .contact-list li {
                flex-basis: 50%
            }

            .footer-container .contact-list li a {
                margin: 5px 10px;
                display: flex;
                align-items: center;
                border-radius: 30px;
                font-size: var(--normal-font);
                background-color: #1c0202;
                color: #fff
            }

            .footer-container .contact-list>li a i {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                -webkit-box-align: center;
                -ms-flex-align: center;
                width: 36px;
                height: 36px;
                margin-right: 10px;
                border-radius: 50%;
                background: #2cfb0a
            }

            .footer-container .contact-list>li a i amp-img {
                margin: 5px;
                flex-basis: 0;
                -ms-flex-preferred-size: 0;
                -webkit-box-flex: 1;
                -ms-flex-positive: 1;
                flex-grow: 1
            }

            .footer-container .bank-list,.footer-container .social-media-list {
                justify-content: center
            }

            .footer-container .social-media-list li {
                flex-basis: 25%
            }

            .footer-container .bank-list li {
                flex-basis: 25%;
                position: relative;
                display: flex;
                justify-content: center;
                padding-bottom: 10px;
                height: 27px
            }

            .footer-container .bank-list span[data-online=false],.footer-container .bank-list span[data-online=true] {
                width: 5px;
                margin-right: 5px;
                border-radius: 2px
            }

            .footer-container .footer-links {
                flex-wrap: wrap;
                justify-content: center
            }

            .footer-container .footer-links li {
                flex-basis: calc(25% - 3px);
                margin-bottom: 5px
            }

            .footer-container .footer-links li a {
                padding: 5px;
                font-size: var(--normal-font);
                color: #ffffff
            }

            .site-description {
                padding: 10px
            }

            .footer-container h1,.footer-container h2,.footer-container h3,.footer-container h4 {
                display: inline
            }

            .copyright {
                padding: 25px 0 20px;
                display: flex;
                flex-direction: column;
                justify-content: center
            }

            .copyright div {
                padding-bottom: 10px
            }

            .fixed-footer {
                display: flex;
                justify-content: space-around;
                position: fixed;
                padding: 5px 0;
                left: 0;
                right: 0;
                bottom: 0;
                z-index: 99
            }

            .fixed-footer a {
                flex-basis: calc((100% - 15px*6)/ 5);
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center
            }

            @media(min-width: 1200px) {
                .container {
                    width:1170px
                }
            }

            @media(min-width: 992px) {
                .container {
                    width:970px
                }
            }

            @font-face {
                font-family: digital_sans_ef_medium;
                src: url('/fonts/digital_sans_ef_medium.woff2') format('woff2'),url('/fonts/digital_sans_ef_medium.woff') format('woff');
                font-weight: 400;
                font-style: normal
            }

            .jackpot-prize {
                position: absolute;
                font-size: 20px;
                bottom: 20%
            }

            .modal-dialog {
                background: rgba(0,0,0,.5);
                width: 100%;
                height: 100%;
                position: absolute;
                display: flex;
                align-items: center;
                justify-content: center
            }

            .modal-content {
                background: #0c0c0c;
                color: #bbb;
                flex-basis: 95%;
                pointer-events: initial;
                border: 5px solid #000;
                border-radius: 10px
            }

            .modal-header {
                background: #0c0c0c;
                text-align: center;
                border-top-left-radius: inherit;
                border-top-right-radius: inherit;
                border-bottom: 0;
                min-height: 50px;
                text-transform: uppercase;
                display: contents
            }

            .modal-header .close {
                opacity: 1;
                margin: 0;
                color: #fff;
                float: right;
                font-size: 21px;
                font-weight: 700;
                line-height: 1;
                text-shadow: 0 1px 0 #fff;
                background-color: transparent;
                border: none
            }

            .modal-body {
                position: relative;
                padding: 20px
            }

            .fixed-footer a {
                background-color: inherit;
                flex-basis: calc((100% - 15px*6)/ 5);
                max-width: 75px;
                font-size: var(--small-font);
                color: #fff
            }

            .fixed-footer .center {
                transform: scale(1);
                background: center/contain no-repeat;
                background-color: inherit;
                border-radius: 50%
            }

            .fixed-footer amp-img {
                max-width: 40%;
                margin-bottom: 5px
            }

            .fixed-footer .live-chat-icon {
                animation: 3s infinite pulse
            }

            .download-apk-container {
                background: var(--image-src);
                background-size: cover;
                display: flex;
                color: #fff;
                align-items: center;
                font-family: sans-serif
            }

            .download-apk-container .popup-modal[data-title] .modal-title:before {
                content: none
            }

            .download-apk-container .popup-modal .modal-header h4 {
                font-size: 24px
            }

            .download-apk-container .popup-modal .modal-body {
                padding-top: 0
            }

            .download-apk-container .popup-modal .modal-body img {
                height: 20px;
                width: 20px
            }

            .download-apk-container .popup-modal .modal-body h5 {
                font-size: 18px;
                color: inherit;
                text-transform: uppercase;
                margin-block-start:0;margin-block-end:0}

            .download-apk-container .popup-modal .modal-body ol {
                list-style: decimal;
                padding-left: 5px;
                line-height: 20px
            }

            .download-apk-container h2,.download-apk-container h3 {
                margin: 0
            }

            .download-apk-container h2 {
                font-weight: 600;
                font-size: var(--x-large-font);
                text-transform: uppercase
            }

            .download-apk-container h3 {
                font-size: var(--small-font);
                font-weight: 100
            }

            .download-apk-container a {
                font-size: var(--small-font);
                text-transform: uppercase
            }

            .download-apk-container>div {
                flex-basis: 50%;
                text-align: center
            }

            .download-apk-container>div:first-child {
                align-self: flex-end
            }

            .download-apk-info {
                display: flex;
                justify-content: center;
                padding: 7px 0
            }

            .download-apk-info>div {
                flex-basis: 45%;
                max-width: 45%
            }

            .download-apk-section {
                text-align: center;
                margin-right: 5px
            }

            .download-apk-section a {
                text-transform: uppercase;
                padding: 2px 0;
                display: block;
                border-radius: 20px;
                text-align: center
            }

            .download-apk-guide {
                color: #fff;
                background-color: transparent;
                border: none;
                text-transform: uppercase;
                font-size: var(--small-font)
            }

            @media(max-width: 575.98px) {
                .download-apk-section amp-img {
                    width:50px
                }
            }

            .logo-container {
                background: linear-gradient(0deg, #E6B800 0%, #FFBF00 100%);
                box-shadow: 0 0 25px #FFAA1D;
                border-bottom: 4px solid #E59400
            }

            .site-menu {
                background-color: #01091a
            }

            .site-menu li>a,.site-menu summary {
                background-color: #020f32;
                color: #fff;
                border-bottom: 1px solid #0351ff
            }

            .jackpot-container .jackpot-prize,.login-button,.main-menu-container li a,.register-button {
                color: #fff
            }

            .register-button {
                background: #ff0000;
                }

            .login-button {
                background: #ffae00;
               }

            
            .main-menu-container {
                background-color: #1c0202
            }

            .footer-container .footer-links,.site-description {
                background-color: #1c0202
            }

            .jackpot-container .jackpot-currency {
                color: #03ffd8
            }

            .footer-container {
                text-align: center;
                color: #E6B800
            }

            .footer-container .bank-list span[data-online=true] {
                background-color: #0f0
            }

            .footer-container .bank-list span[data-online=false] {
                background-color: #e00
            }

            .footer-container .footer-links>li:not(:nth-child(5n+5)):not(:first-child) {
                border-left: 1px solid #fff;
                border-color: #536c80
            }

            .site-description {
                color: #536c9f
            }

            .fixed-footer {
                background: linear-gradient(0deg, #E6B800 0%, #FFBF00 100%);
                box-shadow: 0 0 15px #ffb800e0

            }

            .fixed-footer a.active,.modal-content h4 {
                color: #ff0000
            }

            .download-apk-section a {
                color: #fefefe;
                background: #ff0000;
                background: linear-gradient(to bottom,#ff0000 0,#be0085 100%)
            }

            @media(min-width: 768px) {
                body {
                    font-size:var(--normal-font);
                    padding-top: 80px
                }

                .container {
                    min-width: 768px;
                    max-width: 970px
                }

                .site-menu {
                    width: 20%
                }

                .logo-container .logo {
                    width: 320px;
                    height: 70px
                }

                .footer-container .footer-link,.main-menu-container,.site-description {
                    background-color: transparent
                }

                .register-button {
                    background: #58bfde
                }

                .register-button:hover {
                    background: #a34afb
                }

                .login-button {
                    background: #a844fb;
                    background: linear-gradient(to right,#ee635f 0,#ee635f 100%)
                }

                .login-button:hover {
                    background: #3ebbf3;
                    background: linear-gradient(to right,#ee635f 0,#ee635f 100%)
                }

                .komunitas-button {
                    background: #09f305;
                    background: linear-gradient(to right,#09f305 0,#09f305 100%)
                }

                .komunitas-button:hover {
                    background: #09f305;
                    background: linear-gradient(to right,#09f305 0,#09f305 100%)
                }
            }
            @keyframes colorShift {
    0% { filter: hue-rotate(0deg) saturate(100%); }
    50% { filter: hue-rotate(180deg) saturate(80%); }
    100% { filter: hue-rotate(0deg) saturate(100%); }
}
.icon-transit {
    animation: colorShift 5s linear infinite;
}

        </style>
    </head>
    <body>
        <div class="logo-container">
            <a href="/" class="logo">
                <amp-img layout="fill" src="https://i.ibb.co/hKmsGbH/logo-1.png" alt="<?= htmlspecialchars($pageData['brand']) ?>" noloading></amp-img>
            </a>
        </div>
        <amp-carousel class="carousel-container" layout="responsive" width="1344" height="768" type="slides" autoplay delay="5000" loop>
            <a href="/" target="_blank">
                <amp-img title="<?= htmlspecialchars($pageData['brand']) ?>" src="banner.jpg" alt="<?= htmlspecialchars($pageData['brand']) ?>" width="1344" height="768" layout="responsive"></amp-img>
            </a>
        </amp-carousel>
        <div class="link-container container">
            <a href="https://tinyurl.com/logindulu1/register" class="register-button">Daftar</a>
            <a href="https://tinyurl.com/logindulu1" class="login-button">Masuk</a>
        </div>
        
         <div class="footer-container container">
                 <div class="article" style="padding-top:45px;padding-bottom:25px">
            <h1 style="text-align:center;font-family:Helvetica;font-size:35px;font-weight:10px;"><?= htmlspecialchars($pageData['title']) ?></h1>
            <article>
                
                <p style="text-align:justify;font-family:Helvetica;font-size:22px;color:white"><?= htmlspecialchars($pageData['description']) ?></p>
                
            </article>
            </div>
             <div class="article" style="padding-top:15px;padding-bottom:45px">
                 <amp-img layout="intrinsic"  height="152" width="631" src="https://i.ibb.co/hKmsGbH/logo-1.png"></amp-img>
                 
             </div>
             </div>
       
        <ul class="main-menu-container container" style="text-align:center;">
            <li>
                <a href="/">
                    <amp-img  layout="fixed" height="30" width="30" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgTWZJJWnN2BYMZqM0dfiPCgugyBBo_dPUjSVc5gUJNuqZsNfIVhtw7ojE_IuLxiJiI7r-PLqeHqoosIYj6yNwhtfT_SGl7Xhi4u44pYJSQUZP4nbaPiyNLuf4p5DJODOHwcs1prIJIj2I0BTo2VSsmirJfkxvm1MEpLWWzvrse-ZY9bwD2MUrQ8jBcS237/s693/hot-games.png" alt="Hot Games"></amp-img>
                    Hot Games
    
                </a>
            </li>
            <li>
                <a href="/">
                    <amp-img class="icon-transit" layout="fixed" height="30" width="30" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhungSCd0YY-hh8XKGZr_AGxKdOqZxIrmYqLvML2NG27LVKOsi7RP-Xjr77LAeS3QUHjq3yBzzFnAW8c1xYWDuuJ2CR6sr8UYBwdOdcDqPknw_FqeneDh_Er4HxuxJwTkHSYkNcIKCrc1VnOEyVT3dVxJwJQU_KoG61yE2uk1XcJR9NINVtcD3jb4Tacwlr/s693/slots.png" alt="Slots"></amp-img>
                    Slots
        
                </a>
            </li>
            <li>
                <a href="/">
                    <amp-img class="icon-transit" layout="fixed" height="30" width="30" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjeHh89ozGeWqXlmNkVJiXpmLvuN66Glt53S1Oo-NpvaGG9rOaV9qGM3UZVsOR-80R5YVDhcjgYdXZEo5rWkT0AUs_mXTfrSIGhJBwnB2GTb2tMw43EvNqK_dJ4qxhSUAZkPGBntp2INUi4CqkZqooFV3qXhfHcZ6oIM8qh9hblC5nBjf0MgBM_czYsJI1a/s792/casino.png" alt="Live Casino"></amp-img>
                    Live Casino
        
                </a>
            </li>
            <li>
                <a href="/">
                    <amp-img class="icon-transit" layout="fixed" height="30" width="30" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhCZanj9i5uaNXkpgNciNphXkfZB2VOjc2pz65RhapCqgN0Ps9xnwg2SVMHQa6bjNfF9BugIZ7RlgUHM6WfJm3GG1KYUjPVhSPx298Bw3cugFXk6SPHPT4aLniHMQo7NVT6SIJaaBCUV7WhCet7WpMq-hQaO98xIahHAjgysrudAXmYo3lo9nYGuvfCchOy/s693/others.png" alt="Togel"></amp-img>
                    Togel
        
                </a>
            </li>
            <li>
                <a href="/">
                    <amp-img class="icon-transit" layout="fixed" height="30" width="30" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiEwuA7VyFVGpEdztNzzcmAggXVfWbenoQxf08G3TJbYHeLl-YfgDIKFeQdEMfpM8-T56ltPvbRHyxd4CEFMAhpEC2uXLMY2iivVb84hk9szkpPMggg5QZ-ijOE6rzZW4FanW62dqX-gPz5VGLNsmQ8gsJFFHOrmy1dg5Pq8Ez55xH7t1xRSYG31ilI62yY/s693/sports.png" alt="Olahraga"></amp-img>
                    Olahraga
        
                </a>
            </li>
            <li>
                <a href="/">
                    <amp-img class="icon-transit" layout="fixed" height="30" width="30" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjb1mhvKO0fcmG2j2LERzf5zmmAND2V8r3WaLMfzeOdkhR88lEBHIYUxfQVA06EFg-MC4yi5rx74dctGpA86pSLBNiwmGfKZkGWqD0l5HjYMcuO7zwosFzTlbMoOUSCJwLdkmLSe90zmUhX-2We4tlWhJXuLl3fRSI1uK1SuK1pWxgJU5mxHU0QmTzesQcw/s300/crash-game.png" alt="Crash Game"></amp-img>
                    Crash Game
        
                </a>
            </li>
            <li>
                <a href="/">
                    <amp-img class="icon-transit" layout="fixed" height="30" width="30" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiuLvQrHQV2h7QoYntlZbgXL_7xTc13KNrZ6eghWIKjQK50vTKXzSRxnG3qiuhf4WO8wMQMVUF8Bs5LF8VHWj5F3oPOAxlZN9L5t4fY2-Akp5jMWJFbm-oWcZJpWh1CqrROuHZlZe47laU73PQUn3ffsGGuY3CCPw9VnUDfrnIIcWyoMFLGsPRUUZ_VGfow/s792/arcade.png" alt="Arcade"></amp-img>
                    Arcade
        
                </a>
            </li>
            <li>
                <a href="/">
                    <amp-img class="icon-transit" layout="fixed" height="30" width="30" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhQf4Dz8TWRmQ6zeV7GeVpmkV8IyIcIHQjWHYqW9YKEJNEFehne1HY2lh0vN96L3dYEaWpw8r7UfPvV8-F3dq1mLvLqUxOwlq1_VkgTgNSqmOUBQhtpPYyamV2RIo_m40wYSoGVgMGfsal1gwSZp8Hs47BpameQzd8OkCDmu4WPvnz7q9w5JUcElLWT6HK5/s30/e-sports.png" alt="E-Sports"></amp-img>
                    E-Sports
        
                </a>
            </li>
        </ul>
        <footer class="footer-container container">
             
                    <div class="fixed-footer">
                        <a href="https://tinyurl.com/logindulu1">
                            <amp-img layout="intrinsic" height="75" width="75" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEit7oRU8pHnAcHLhichJDh2m_m0ViliStt9Yrymi0B3z-pP-tS6so3MLA0JEVCgGOW8qiSnp4pBgqT4wQlobbzh5Y2M9rUgDnrKvjwI_mtUxdcj5S0fVYfndZ-8O4O230-nikPI-VAhtxvCpAka5BnAsFFJB1f5SOHlobk2vj8Vy0p3ePQHRSnQM0Y4V0Tg/s42/home-active.png" class="icon-transit"
alt="Beranda"></amp-img>
                            Beranda
        
                        </a>
                        <a href="https://tinyurl.com/logindulu1">
                            <amp-img layout="intrinsic" class="icon-transit" height="75" width="75" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgXXx5LO2dCICUJf7EKSyVeR6gRAqYvWYBNOySeYBhkYhLbtZJV3in7sWOyOwwRLS-UMthTjv-Iqcu0W4LxYKjI3eqn81aQCEjZXn0SddY9wKRYuXw3UTeq_06EomBNzL6C_J4NiJXmQ2e8t5nzqHFAmO0O6gLQmw-jSweoUDT7CrmrFHWF1ZwiunKgcCko/s20/mobile-app.png" alt="Unduh"></amp-img>
                            Unduh
            
                        </a>
                        <a href="https://tinyurl.com/logindulu1">
                            <amp-img class="center icon-transit" layout="intrinsic" height="75" width="75" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEia7PEWuHm5i6Y8CikK__6Y8BToXNFPvKF29BADv6J1Nw3ZdpwL6DQ9Wbwl7d9RPN_Qidf2-KUMYWQ4k96_FAf1BISWIDCO0OVPAQD9s_KYtILyzHC248niRH7PojTTPoT0yCat2JACYAy_N4cBnp7QvEANlvyVKsq3dkf0eficl9XuYaUtadLvK3LRGJDn/s32/login2.png" alt="Masuk"></amp-img>
                            Masuk
        
                        </a>
                        <a href="https://tinyurl.com/logindulu1/promotion">
                            <amp-img layout="intrinsic" class="icon-transit" height="75" width="75" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgjcPLm8RDyTumt_QmVnFIC6x7F_fSo_-QRNFSuEN-MT4O_tF181Z7K7wJ46EWXJOJLFNIKya-vdG1DQtSjhe0sSoYJCI3l9ZGVNNkxx-zw6KvtkfC5hn36WdfJbwuTbN5CY7Wy-4ALfvoTrEje4IjkIIOoanlqafCSm66svrKKQJ7UOWistaHkdw714vPK/s42/promotion.png" alt="Promosi"></amp-img>
                            Promosi
        
                        </a>
                        
                    </div>
                    
    </body>
    <footer style="padding-bottom:25px;padding-top:55px">
                        ©2025 <a href="<?= htmlspecialchars($canonical) ?>"><?= htmlspecialchars($pageData['brand']) ?></a>. Situs resmi daftar dan login game online melayani 24/7 jam penuh. All rights reserved | 18+
                    </footer>
</html>